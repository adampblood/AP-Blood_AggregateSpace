###Module of tools to generate voxel space and corresponding Block Instances

###LIBRARIES
import rhinoscriptsyntax as rs

###DEFINITIONS

#"cube_grid" creates a cubic grid of points; 
## arguments are cube dimensions, resolution of grid; returns point coordinates
def cube_grid(x_number, y_number, z_number, space):
    x_n = int(x_number)
    y_n = int(y_number)
    z_n = int(z_number)
    
    coords = []
    
    int_space = int(space)
    
    for i in range(0, x_n, int_space):
        for j in range(0, y_n, int_space):
            for p in range (0, z_n, int_space):
                x_val = i
                y_val = j
                z_val = p
                coords.append((x_val, y_val, z_val))
                
    return coords

#"create_voxel_block" creates a block based upon cubic voxel;
##argument need is for block "radius"; no return
def create_voxel_block(Radius):
    
    Cx = 0
    Cy = 0
    Cz = 0
    
    #lower 4 points
    p1 = (Cx-Radius,Cy-Radius,Cz-Radius)
    p2 = (Cx+Radius,Cy-Radius,Cz-Radius)
    p3 = (Cx+Radius,Cy+Radius,Cz-Radius)
    p4 = (Cx-Radius,Cy+Radius,Cz-Radius)

    #upper 4 points
    p5 = (Cx-Radius,Cy-Radius,Cz+Radius)
    p6 = (Cx+Radius,Cy-Radius,Cz+Radius)
    p7 = (Cx+Radius,Cy+Radius,Cz+Radius)
    p8 = (Cx-Radius,Cy+Radius,Cz+Radius)

    #make a box
    Box = rs.AddBox([p1,p2,p3,p4,p5,p6,p7,p8])
    rs.AddBlock([Box],(Cx,Cy,Cz),"block_voxel", delete_input=True)

#"cull_in_bound" interprets interior and exterior points of grid;
##applies voxel_block to exterior points
###arguments needed are for point list(usually cube_grid),
####single brep(Boolean'd Geometry), grid resolution; returns point list
def cull_in_bound(plist,brep,res):
    
    create_voxel_block(res)
    points = []
    for i in plist:
        if brep.IsPointInside(i,.01, True) == False:
            rs.InsertBlock("block_voxel",i)
            rs.EnableRedraw(False)
            
    return(points)

#"cull_in_pts" interprets interior and exterior points of grid;
##culls interior points from grid
###arguments needed are for point list(usually cube_grid),
####single brep(usually Boolean'd site Geometry); returns list of exterior pts
def cull_in_pts(plist,brep):
    
    points = []
    for i in plist:
        if brep.IsPointInside(i,.01, True) == False:
            points.append(i)
            rs.EnableRedraw(False)
            
    return(points)

#"cull_out_bound" interprets interior and exterior points of grid;
##applies voxel_block to exterior points
###arguments needed are for point list(usually cube_grid),
####single brep(Boolean'd Geometry), grid resolution; returns point list
def cull_out_bound(plist,brep,res):
    
    create_voxel_block(res)
    points = []
    for i in plist:
        if brep.IsPointInside(i,.01, True) == True:
            rs.InsertBlock("block_voxel",i)
            rs.EnableRedraw(False)
            
    return(points)

################################################################################


