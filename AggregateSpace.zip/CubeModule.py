###Module of functions to generate different types of CUBE bReps

###LIBRARIES
import rhinoscriptsyntax as rs

################################################################################

#Function creates a Cube based on a primary corner point;
##Arguments needed are for base point, length of vertices; returns brep
def cube(Base,Length):
    
    #Identify facets of a cube in relation to the center
    
    Bx = Base[0]
    By = Base[1]
    Bz = Base[2]
    
    #Bottom corners of the cube
    p1 = (Bx,By,Bz)
    p2 = (Bx,By+Length,Bz)
    p3 = (Bx+Length,By+Length,Bz)
    p4 = (Bx+Length,By,Bz)
    
    #Top corners of the Cube
    p5 = (Bx,By,Bz+Length)
    p6 = (Bx,By+Length,Bz+Length)
    p7 = (Bx+Length,By+Length,Bz+Length)
    p8 = (Bx+Length,By,Bz+Length)
    
    Box = rs.AddBox([p1,p2,p3,p4,p5,p6,p7,p8])
    
    return(Box)

#Function creates a cube based on volume centroid;
##Arguments needed are for centroid, 1/2 length of edges (radius);
###returns brep
def ctr_cube(Center,Radius):
    
    #Identify facets of a cube in relation to the center
    
    Cx = Center[0]
    Cy = Center[1]
    Cz = Center[2]
    
    #Bottom corners of the cube
    p1 = (Cx-Radius,Cy-Radius,Cz-Radius)
    p2 = (Cx+Radius,Cy-Radius,Cz-Radius)
    p3 = (Cx+Radius,Cy+Radius,Cz-Radius)
    p4 = (Cx-Radius,Cy+Radius,Cz-Radius)
    
    #Top corners of the Cube
    p5 = (Cx-Radius,Cy-Radius,Cz+Radius)
    p6 = (Cx+Radius,Cy-Radius,Cz+Radius)
    p7 = (Cx+Radius,Cy+Radius,Cz+Radius)
    p8 = (Cx-Radius,Cy+Radius,Cz+Radius)
    
    Box = rs.AddBox([p1,p2,p3,p4,p5,p6,p7,p8])
    
    return(Box)

#Function creates cuboid from primary corner point;
##Arguments needed are for base point, length,width,height dimensions; returns brep
def cuboid(Base,xLen,yLen,zLen):
    
    #Identify facets of a cube in relation to the center
    
    Bx = Base[0]
    By = Base[1]
    Bz = Base[2]
    
    #Bottom corners of the cube
    p1 = (Bx,By,Bz)
    p2 = (Bx,By+yLen,Bz)
    p3 = (Bx+xLen,By+yLen,Bz)
    p4 = (Bx+xLen,By,Bz)
    
    #Top corners of the Cube
    p5 = (Bx,By,Bz+zLen)
    p6 = (Bx,By+yLen,Bz+zLen)
    p7 = (Bx+xLen,By+yLen,Bz+zLen)
    p8 = (Bx+xLen,By,Bz+zLen)
    
    Box = rs.AddBox([p1,p2,p3,p4,p5,p6,p7,p8])
    
    return(Box)

#Function creates cuboid based on volume centroid;
##Arguments needede are for centroid, length,width,height dimensions; returns brep
def ctr_cuboid(Center,xLen,yLen,zLen):
    
    #Identify facets of a cube in relation to the center
    
    Cx = Center[0]
    Cy = Center[1]
    Cz = Center[2]
    
    #Bottom corners of the cube
    p1 = (Cx-(xLen/2),Cy-(yLen/2),Cz-(zLen/2))
    p2 = (Cx+(xLen/2),Cy-(yLen/2),Cz-(zLen/2))
    p3 = (Cx+(xLen/2),Cy+(yLen/2),Cz-(zLen/2))
    p4 = (Cx-(xLen/2),Cy+(yLen/2),Cz-(zLen/2))
    
    #Top corners of the Cube
    p5 = (Cx-(xLen/2),Cy-(yLen/2),Cz+(zLen/2))
    p6 = (Cx+(xLen/2),Cy-(yLen/2),Cz+(zLen/2))
    p7 = (Cx+(xLen/2),Cy+(yLen/2),Cz+(zLen/2))
    p8 = (Cx-(xLen/2),Cy+(yLen/2),Cz+(zLen/2))
    
    Box = rs.AddBox([p1,p2,p3,p4,p5,p6,p7,p8])
    
    return(Box)

#Function creates list of anchor points arrayed along lower cuboid edges
##Arguments needed are for centroid, length,width,height dimensions; returns point list
def cuboid_anchors(Center,xLen,yLen,zLen):
    
    #Identify facets of a cube in relation to the center
    
    Cx = Center[0]
    Cy = Center[1]
    Cz = Center[2]
    
    anchors = []
    
    #Bottom corners of the cube
    p1 = (Cx-(xLen/2),Cy-(yLen/2),Cz-(zLen/2))
    p2 = (Cx+(xLen/2),Cy-(yLen/2),Cz-(zLen/2))
    p3 = (Cx+(xLen/2),Cy+(yLen/2),Cz-(zLen/2))
    p4 = (Cx-(xLen/2),Cy+(yLen/2),Cz-(zLen/2))
    
    l1 = rs.AddLine(p1,p2)
    l2 = rs.AddLine(p2,p3)
    l3 = rs.AddLine(p3,p4)
    l4 = rs.AddLine(p4,p1)
    
    lines = [l1,l2,l3,l4]
    
    for i in lines:
        
        anchor_pts = rs.DivideCurve(i,4,create_points=False)
        
        for i in anchor_pts:
            anchors.append(i)
    
    rs.DeleteObjects(lines)
    
    del anchors[0]
    del anchors[3]
    del anchors[3]
    del anchors[6]
    del anchors[6]
    del anchors[9]
    del anchors[9]
    del anchors[12]
    
    return(anchors)

################################################################################

