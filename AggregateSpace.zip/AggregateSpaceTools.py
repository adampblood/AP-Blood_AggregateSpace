###Module of tools to generate voxel space and corresponding Block Instances

###LIBRARIES
import rhinoscriptsyntax as rs
import random

###CUSTOM MODULES
import CubeModule as cm

################################################################################
###Aggregate Space Definitions; for residential project

#Function creates residential living "units" based on shared and private spaces
##Arguments needed are number of units, point list, grid resolution; no returns
def unit_builder(plist,unit_count,project_height,resolution):
    
    res_height = float(project_height/2)
    
    circ_pts = filter(lambda z: z[2] > res_height, plist)
    base_pts = list(circ_pts)
    
    for i in range(unit_count):
        
        length = random.randrange(20,32,resolution)
        width = random.randrange(20,32,resolution)
        height = random.randrange(8,16,resolution)
        
        point = random.choice(base_pts)
        shared = cm.ctr_cuboid(point,length,width,height)
        anchors = cm.cuboid_anchors(point,length,width,height)
        
        room_count = random.randint(0,4)
        
        for i in range(room_count):
            
            pt = random.choice(anchors)
            length = random.randint(10,16)
            width = random.randint(10,16)
            height = random.randint(7,12)
            
            private = cm.cuboid(pt,length,width,height)

#Function creates vertical circulation shafts for "Aggregate Space"
##Arguments needed are point list, number of residential units, project height,
### grid resolution; returns brep(s) 
def vertical_circulation(plist,unit_count,project_height,resolution):
    
    u_range = range(unit_count)
    shaft_num = u_range[::5]
    
    circ_pts = filter(lambda z: z[2] < 4, plist)
    base_pts = list(circ_pts)
    
    for i in shaft_num:
        
        pt = random.choice(base_pts)
        radius = random.randrange(4,8,resolution)
        ht_z = int(pt[2])
        zLen = (project_height - ht_z)
        v_shaft = rs.AddCylinder(pt,zLen,radius,cap=True)
    
    return(v_shaft)

#Definition for creating circulation corridors (based upon # of units)
##Arguments needed are point list, number of residential units, project length,
### grid resolution; returns brep(s)
def horizontal_circulation(plist,unit_count,project_length,project_height,resolution):
    
    res_height = float(project_height/2)
    
    u_range = range(unit_count)
    shaft_num = u_range[::5]
    
    circ_pts_a = filter(lambda z: z[2] >= res_height, plist)
    z_pts = list(circ_pts_a)
    
    circ_pts_b = filter(lambda x: x[0] <= 54, z_pts)
    base_pts = list(circ_pts_b)
    
    for i in shaft_num:
        
        pt = random.choice(base_pts)
        
        len_x = int(pt[0])
        xLen = (project_length - len_x)
        yLen = random.randrange(6,20,resolution)
        zLen = random.randrange(12,20,resolution)
        corridor = cm.cuboid(pt,xLen,yLen,zLen)
    
    return(corridor)

#Function for creating public spaces based on chosen points in site
##Agruments needed are project height; no returns
def public_space(project_height):
    
    pt = rs.GetPoint("Choose Center Point for Geometry")
    geo = random.randint(0,1)
    
    if geo == 0:
        
        radius = 25
        rs.AddSphere(pt, radius)
    if geo == 1:
        
        radius = 25
        rs.AddCylinder(pt,project_height,radius,cap=True)
    
    rs.Command("Ellipsoid")

################################################################################