#
#       Adam Blood // Woodbury University // Spring 2022 // 
#       Thesis Studio "Lossy" // Professor Mark Ericson
#
#       This Project is designed for low resolution architectural design.
#       The process divides buildable space into a voxel grid. Spatial primitives
#       behave within a set of parameters to generate architectural program.
#       A formal cube is aggregated around the space to generate architectural form

###LIBRARIES
import Rhino
import rhinoscriptsyntax as rs
import math
import random
import scriptcontext as sc
import System

###CUSTOM MODULES
import AggregateSpaceTools as ag
import CubeModule as cm
import VoxelTools as vt

################################################################################

def main():
    
    x_val = rs.GetInteger("What is the project Length?")
    y_val = rs.GetInteger("What is the project Width?")
    z_val = rs.GetInteger("What is the project Height?")
    
    resolution = rs.GetInteger("Choose Project Resolution (1-20)")
    radius = float(resolution/2)
    
    unit_count = rs.GetInteger("NOTE: This version of Plugin is configured for Residential Projects; How Many Residential Units Does the Project Need?")
    rs.EnableRedraw(enable=True)
    
    site = rs.GetObject("Choose Existing Site bRep (If none, press ESC)")
    
    if site != None:
        site_brep = rs.coercebrep(site)
        grid = vt.cube_grid(x_val,y_val,z_val,resolution)
        points_full = rs.coerce3dpointlist(grid)
        
        cull_pts = vt.cull_in_pts(points_full,site_brep)
        ag_pts = rs.coerce3dpointlist(cull_pts)
    
    else:
        grid = vt.cube_grid(x_val,y_val,z_val,resolution)
        ag_pts = rs.coerce3dpointlist(grid)
    
    rs.EnableRedraw(enable=True)
    
    ag.unit_builder(ag_pts,unit_count,z_val,resolution)
    rs.EnableRedraw(enable=True)
    
    ag.vertical_circulation(ag_pts,unit_count,z_val,resolution)
    rs.EnableRedraw(enable=True)
    
    ag.horizontal_circulation(ag_pts,unit_count,x_val,z_val,resolution)
    rs.EnableRedraw(enable=True)
    
    pts = rs.Command("SelPt")
    rs.Command("Delete")
    rs.EnableRedraw(enable=True)
    
    floaters = rs.GetObjects("Choose Floating Objects to Delete")
    if floaters:
        rs.DeleteObjects(floaters)
    else:
        pass
    
    rs.EnableRedraw(enable=True)
    
    rs.Command("BooleanUnion")
    boolu = rs.GetObject("Choose Boolean'd Geometry")
    
    brep = rs.coercebrep(boolu)
    
    vt.cull_in_bound(ag_pts,brep,radius)

main()

